package com.tiendaonline.tienda_online_jpa.repository;

import com.tiendaonline.tienda_online_jpa.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    Optional<Categoria> findByNombre(String nombre);
}