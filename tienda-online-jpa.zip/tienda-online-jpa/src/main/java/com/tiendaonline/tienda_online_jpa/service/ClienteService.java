package com.tiendaonline.tienda_online_jpa.service;

import com.tiendaonline.tienda_online_jpa.model.Cliente;
import com.tiendaonline.tienda_online_jpa.repository.ClienteRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    public Cliente save(Cliente cliente) {
        // Lógica de negocio antes de guardar (e.g., setear la bidireccionalidad)
        if (cliente.getDireccion() != null) {
            cliente.getDireccion().setCliente(cliente);
        }
        return clienteRepository.save(cliente);
    }

    public Optional<Cliente> findById(Long id) {
        return clienteRepository.findById(id);
    }

    // AÑADE ESTE MÉTODO FALTANTE
    public List<Cliente> findAllWithDireccion() {
        return clienteRepository.findAllWithDireccion();
    }

    // ... otros métodos de servicio
}