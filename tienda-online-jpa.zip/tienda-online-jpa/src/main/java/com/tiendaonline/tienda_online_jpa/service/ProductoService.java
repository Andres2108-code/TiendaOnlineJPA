package com.tiendaonline.tienda_online_jpa.service;

import com.tiendaonline.tienda_online_jpa.model.Categoria;
import com.tiendaonline.tienda_online_jpa.model.Producto;
import com.tiendaonline.tienda_online_jpa.repository.CategoriaRepository;
import com.tiendaonline.tienda_online_jpa.repository.ProductoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;
import java.util.Set;

@Service
public class ProductoService {

    private final ProductoRepository productoRepository;
    private final CategoriaRepository categoriaRepository;

    public ProductoService(ProductoRepository productoRepository, CategoriaRepository categoriaRepository) {
        this.productoRepository = productoRepository;
        this.categoriaRepository = categoriaRepository;
    }

    @Transactional
    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }

    public Page<Producto> findAll(Pageable pageable) {
        return productoRepository.findAll(pageable);
    }

    public Page<Producto> findByCategoria(String nombreCategoria, Pageable pageable) {
        return productoRepository.findByCategorias_Nombre(nombreCategoria, pageable);
    }

    @Transactional
    public Producto asignarCategorias(Long productoId, Set<String> nombresCategorias) {
        Producto producto = productoRepository.findById(productoId)
                .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + productoId));

        producto.getCategorias().clear();

        for (String nombre : nombresCategorias) {
            Optional<Categoria> categoriaOpt = categoriaRepository.findByNombre(nombre);

            Categoria categoria;
            if (categoriaOpt.isPresent()) {
                categoria = categoriaOpt.get();
            } else {
                categoria = new Categoria();
                categoria.setNombre(nombre);
                categoria = categoriaRepository.save(categoria);
            }
            producto.getCategorias().add(categoria);
        }

        return productoRepository.save(producto);
    }
}