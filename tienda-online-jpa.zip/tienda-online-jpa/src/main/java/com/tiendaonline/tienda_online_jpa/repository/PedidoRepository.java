package com.tiendaonline.tienda_online_jpa.repository;

import com.tiendaonline.tienda_online_jpa.dto.TotalClienteDTO;
import com.tiendaonline.tienda_online_jpa.model.Pedido;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    @EntityGraph(attributePaths = {"items", "items.producto"})
    Optional<Pedido> findById(Long id);

    @Query("SELECT new com.tiendaonline.tienda_online_jpa.dto.TotalClienteDTO(p.cliente.id, SUM(p.total)) " +
            "FROM Pedido p GROUP BY p.cliente.id")
    List<TotalClienteDTO> sumTotalByCliente();
}