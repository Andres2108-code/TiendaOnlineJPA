package com.tiendaonline.tienda_online_jpa.dto; // <--- Debe coincidir con tu paquete base + .dto

import lombok.AllArgsConstructor;
import lombok.Getter;
import java.math.BigDecimal;

@Getter
@AllArgsConstructor
public class TotalClienteDTO {

    private Long clienteId;
    private BigDecimal totalPedidos;
}