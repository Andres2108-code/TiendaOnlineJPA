package com.tiendaonline.tienda_online_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaOnlineJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaOnlineJpaApplication.class, args);
	}

}
