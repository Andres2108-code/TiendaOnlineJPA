package com.tiendaonline.tienda_online_jpa.repository;

import com.tiendaonline.tienda_online_jpa.model.Producto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    Page<Producto> findByCategorias_Nombre(String nombre, Pageable pageable);
}