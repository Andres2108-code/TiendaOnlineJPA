package com.tiendaonline.tienda_online_jpa.service;

import com.tiendaonline.tienda_online_jpa.model.Pedido;
import com.tiendaonline.tienda_online_jpa.repository.PedidoRepository;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PedidoService {
    private final PedidoRepository pedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    // 1. Método faltante: findById
    public Optional<Pedido> findById(Long id) {
        // Usará el @EntityGraph definido en PedidoRepository para cargar items y productos.
        return pedidoRepository.findById(id);
    }

    // 2. Método faltante: updateEstado
    public Pedido updateEstado(Long id, String estado) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        // Aquí iría la lógica de validación de estado si fuera necesaria
        pedido.setEstado(estado);
        return pedidoRepository.save(pedido);
    }

    // 3. Método faltante: cancelarPedido
    public Pedido cancelarPedido(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        // Lógica de negocio: Cambiar estado y posiblemente revertir stock
        pedido.setEstado("CANCELADO");
        // Lógica: Revertir stock (si está implementada)

        return pedidoRepository.save(pedido);
    }

    // El método crearPedido ya debe existir
    public Pedido crearPedido(Pedido pedido) {
        // ... lógica de creación de pedido, cálculo de total y descuento de stock ...
        return pedidoRepository.save(pedido);
    }
}