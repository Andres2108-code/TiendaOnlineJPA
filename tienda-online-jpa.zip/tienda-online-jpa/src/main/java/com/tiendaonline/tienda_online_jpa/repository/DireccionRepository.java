package com.tiendaonline.tienda_online_jpa.repository;

import com.tiendaonline.tienda_online_jpa.model.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DireccionRepository extends JpaRepository<Direccion, Long> {
}