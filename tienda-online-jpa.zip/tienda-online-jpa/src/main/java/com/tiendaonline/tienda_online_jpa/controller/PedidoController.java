package com.tiendaonline.tienda_online_jpa.controller;

import com.tiendaonline.tienda_online_jpa.model.Pedido;
import com.tiendaonline.tienda_online_jpa.service.PedidoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    // 1. GET /pedidos/{id} (DTO con items y totales)
    @GetMapping("/{id}")
    public ResponseEntity<Pedido> getPedido(@PathVariable Long id) {
        Optional<Pedido> pedidoOpt = pedidoService.findById(id);

        return pedidoOpt
                // Si el pedido existe, lo mapeamos a ResponseEntity.ok(pedido)
                .map(ResponseEntity::ok)
                // Si no existe (Optional.empty), devolvemos un 404
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // 2. PUT /pedidos/{id}/estado/{valor} (Cambiar estado)
    @PutMapping("/{id}/estado/{valor}")
    public ResponseEntity<Pedido> cambiarEstadoPedido(
            @PathVariable Long id,
            @PathVariable String valor) {

        if ("CANCELADO".equalsIgnoreCase(valor)) {
            // Si el valor es CANCELADO, llama a la lógica de negocio que revierte el stock.
            // Regla de Negocio: Revertir stock si se cancela
            Pedido pedidoCancelado = pedidoService.cancelarPedido(id);
            return ResponseEntity.ok(pedidoCancelado);
        }

        // Para cualquier otro estado (PAGADO, ENVIADO), asume una simple actualización.
        Pedido pedidoActualizado = pedidoService.updateEstado(id, valor);
        return ResponseEntity.ok(pedidoActualizado);
    }
}