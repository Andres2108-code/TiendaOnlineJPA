package com.tiendaonline.tienda_online_jpa.controller;

import com.tiendaonline.tienda_online_jpa.model.Producto;
import com.tiendaonline.tienda_online_jpa.service.ProductoService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Set;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @PostMapping
    public ResponseEntity<Producto> crearProducto(@RequestBody Producto producto) {
        Producto nuevoProducto = productoService.save(producto);
        return new ResponseEntity<>(nuevoProducto, HttpStatus.CREATED);
    }

    @PostMapping("/{id}/categorias")
    public ResponseEntity<Producto> asignarCategorias(
            @PathVariable Long id,
            @RequestBody Set<String> nombresCategorias) {

        Producto productoActualizado = productoService.asignarCategorias(id, nombresCategorias);
        return ResponseEntity.ok(productoActualizado);
    }

    @GetMapping
    public ResponseEntity<Page<Producto>> listarProductos(
            @RequestParam(required = false) String categoria,
            Pageable pageable) {

        Page<Producto> productos;
        if (categoria != null && !categoria.isEmpty()) {
            productos = productoService.findByCategoria(categoria, pageable);
        } else {
            productos = productoService.findAll(pageable);
        }

        return ResponseEntity.ok(productos);
    }
}