package com.tiendaonline.tienda_online_jpa.controller;

import com.tiendaonline.tienda_online_jpa.model.Cliente;
import com.tiendaonline.tienda_online_jpa.model.Pedido;
// Asegúrate de importar todas las clases necesarias
import com.tiendaonline.tienda_online_jpa.service.ClienteService;
import com.tiendaonline.tienda_online_jpa.service.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService clienteService;
    private final PedidoService pedidoService; // Asegúrate de tener esta dependencia si la usas

    public ClienteController(ClienteService clienteService, PedidoService pedidoService) {
        this.clienteService = clienteService;
        this.pedidoService = pedidoService;
    }

    // 1. POST /clientes (Crear cliente con dirección)
    @PostMapping
    public ResponseEntity<Cliente> crearCliente(@RequestBody Cliente cliente) {
        // La bidireccionalidad de la dirección se establece en el modelo antes de guardar.
        // Permite crear Cliente con su Direccion en una sola operación
        Cliente nuevoCliente = clienteService.save(cliente);
        return new ResponseEntity<>(nuevoCliente, HttpStatus.CREATED);
    }

    // 2. POST /{clienteId}/pedidos (Crear pedido con items)
    @PostMapping("/{clienteId}/pedidos")
    public ResponseEntity<Pedido> crearPedido(
            @PathVariable Long clienteId,
            @RequestBody Pedido pedido) {

        // CORRECCIÓN: Usar el método findById expuesto en ClienteService
        Cliente cliente = clienteService.findById(clienteId)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));

        // Asignar el cliente al pedido para establecer la FK
        pedido.setCliente(cliente);

        // La lógica de stock, validación, y cálculo de total se ejecuta en PedidoService.crearPedido
        Pedido nuevoPedido = pedidoService.crearPedido(pedido);
        return new ResponseEntity<>(nuevoPedido, HttpStatus.CREATED);
    }

    // Opcional: GET /clientes/{id} (para pruebas)
    @GetMapping("/{id}")
    public ResponseEntity<Cliente> getCliente(@PathVariable Long id) {
        // Si necesitas cargar la dirección, deberías usar un DTO o el @EntityGraph
        // en el repositorio. Por simplicidad, usamos findById.
        Cliente cliente = clienteService.findById(id)
                .orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
        return ResponseEntity.ok(cliente);
    }

    // Opcional: GET /clientes (para pruebas del findAllWithDireccion)
    @GetMapping
    public ResponseEntity<List<Cliente>> getAllClientesWithDireccion() {
        // Llama al método optimizado con EntityGraph
        List<Cliente> clientes = clienteService.findAllWithDireccion();
        return ResponseEntity.ok(clientes);
    }
}