package com.tiendaonline.tienda_online_jpa.repository;

import com.tiendaonline.tienda_online_jpa.model.Cliente;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Optional;
import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Optional<Cliente> findByEmail(String email);
    @EntityGraph(attributePaths = "direccion")
    @Query("SELECT c FROM Cliente c")
    List<Cliente> findAllWithDireccion();
}