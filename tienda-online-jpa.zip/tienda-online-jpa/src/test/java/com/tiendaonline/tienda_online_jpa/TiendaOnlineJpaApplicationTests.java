package com.tiendaonline.tienda_online_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaOnlineJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
